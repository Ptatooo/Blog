class PublicController < ApplicationController

  def index
  end

end

require 'test_helper'

class AccTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
